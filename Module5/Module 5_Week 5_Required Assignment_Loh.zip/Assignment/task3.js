const fruits = ["apple","orange","mango","pineapple"];

console.log('---Start of fruits---');

for (i=0; i<fruits.length; i++) {
    console.log(fruits[i]);
}

console.log('---End of fruits---');