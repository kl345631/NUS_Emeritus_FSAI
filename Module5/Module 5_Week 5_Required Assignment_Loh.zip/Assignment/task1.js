
var name , age, isStudent;

name = 'Alice';
age = 22;
isStudent = true;

console.log ('Name = ' + name);
console.log('Data Type: ' + typeof name);
console.log('---------------------------');
console.log ('Age = ' + age);
console.log('Data Type: ' + typeof age);
console.log('---------------------------');
console.log ('isStudent = true')
console.log('Data Type: ' + typeof isStudent);
console.log('---------------------------');