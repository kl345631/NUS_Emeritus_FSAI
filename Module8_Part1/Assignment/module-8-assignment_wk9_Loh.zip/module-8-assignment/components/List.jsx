export default function ToDoList ({tasks}) {
    return (
        <>
            <ul>
                 {tasks.map((t,index) => (
                    <li key={index}> {t} </li>
                 ))} 
            </ul>
        </>
    )
}