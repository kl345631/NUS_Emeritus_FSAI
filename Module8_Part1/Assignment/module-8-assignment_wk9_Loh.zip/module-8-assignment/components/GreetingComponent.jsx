export default function GreetingComponent({name}) {
    return (
        <div>
            <h1>Hello, {name}!</h1>
        </div>
    );
}